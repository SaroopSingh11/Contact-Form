# Contact Form

A sleek and responsive contact form built with HTML, CSS, and JavaScript. This project features a modern UI design with client-side validation and a dark gradient theme using Google Fonts and custom styling.

## 📸 Preview


## ✨ Features

- Fully responsive layout
- Elegant linear gradient dark theme
- Font styling with Google Fonts (Poppins)
- Client-side input validation for all fields
- Real-time email format checking
- Confirmation alert after form submission
- Reset form after successful submission

## 🧰 Technologies Used

- HTML5 – Form structure
- CSS3 – Layout, styling, gradients
- JavaScript – Form validation and submission feedback
- Google Fonts – Poppins for modern typography



